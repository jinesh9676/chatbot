from app import app

if _name_ == "_main_":
    app.run()